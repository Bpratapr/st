from datetime import datetime
from typing import Union

from arrow import Arrow

ArrowLike = Union[datetime, Arrow]
